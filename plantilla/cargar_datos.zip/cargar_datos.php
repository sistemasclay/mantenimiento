
<?php
include("../clases/configuracion_aplicacion.php");
$datos = new configuracion_aplicacion();

/** Error reporting */
error_reporting(E_ALL);

/** PHPExcel */
require_once '../clases/PHPExcel.php';

/** PHPExcel_IOFactory */
require_once '../clases/PHPExcel/IOFactory.php';
require_once '../clases/PHPExcel/Reader/Excel5.php';

$objReader = new PHPExcel_Reader_Excel5();
$objPHPExcel = $objReader->load("Planilla BD Clay VERSION 10.0.xls");


//leer las plantas

$objPHPExcel->setActiveSheetIndex(1);//plantas
$leer_siguiente=1;
$filas_excel=3;
$indice_array=0;
$valor_celda="";
while($leer_siguiente==1)
{
   $valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   if($valor_celda=="")
   {
       $leer_siguiente=0;
   }
   else
   {
   $plantas["id_planta"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   $plantas["nombre"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$filas_excel)->getValue();
   $plantas["descripcion"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$filas_excel)->getValue();
   $filas_excel++;
   $indice_array++;
   }
}
//print_r($plantas);


$objPHPExcel->setActiveSheetIndex(2);//procesos
$leer_siguiente=1;
$filas_excel=3;
$indice_array=0;
$valor_celda="";
while($leer_siguiente==1)
{
   $valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   if($valor_celda=="")
   {
       $leer_siguiente=0;
   }
   else
   {
   $procesos["id_proceso"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   $procesos["nombre"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$filas_excel)->getValue();
   $procesos["id_planta"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$filas_excel)->getValue();
   $procesos["ip"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(3,$filas_excel)->getValue();
   $procesos["max_horas"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(4,$filas_excel)->getValue();
   $procesos["descripcion"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(5,$filas_excel)->getValue();
   $procesos["tipo_captura"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(6,$filas_excel)->getValue();
   $filas_excel++;
   $indice_array++;
   }
}
//print_r($procesos);


$objPHPExcel->setActiveSheetIndex(3);//Materiales
$leer_siguiente=1;
$filas_excel=3;
$indice_array=0;
$valor_celda="";
while($leer_siguiente==1)
{
   $valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   if($valor_celda=="")
   {
       $leer_siguiente=0;
   }
   else
   {
   $materiales["id_material"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   $materiales["nombre"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$filas_excel)->getValue();
   $materiales["descripcion"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$filas_excel)->getValue();
   $materiales["unidad"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(3,$filas_excel)->getValue();
   $filas_excel++;
   $indice_array++;
   }
}
//print_r($materiales);




$objPHPExcel->setActiveSheetIndex(4);//echo "Productos";

$leer_siguiente=1;
$filas_excel=3;
$indice_array_producto=0;
$indice_array_p_p=0;
$indice_array_receta=0;
$producto_eva="";//para comparar que no se repita
$pp_eval="";
$valor_celda="";
while($leer_siguiente==1)
{
   $valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   if($valor_celda=="") //si llego al final sale del while
   {
       $leer_siguiente=0;
   }
   else
   {
                if($producto_eva!=$valor_celda) //si el no esta repetido
                {
                $productos["id_producto"][$indice_array_producto]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
                $productos["nombre"][$indice_array_producto]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$filas_excel)->getValue();
                $productos["descripcion"][$indice_array_producto]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$filas_excel)->getValue();

                $producto_p["id_producto"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
                $producto_p["id_proceso"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(9,$filas_excel)->getValue();
                $producto_p["unidades_pulso"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(10,$filas_excel)->getValue();
                $producto_p["var_pp1"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(11,$filas_excel)->getValue();

                $res=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(20,$filas_excel)->getValue();
                if($res!="") //si hay receta
                {
                $receta["id_producto"][$indice_array_receta]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
                $receta["id_material"][$indice_array_receta]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(20,$filas_excel)->getValue();
                $receta["cantidad"][$indice_array_receta]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(21,$filas_excel)->getValue();
                $indice_array_receta++;
                }

                $producto_eva=$productos["id_producto"][$indice_array_producto];
                $pp_eval=$producto_p["id_proceso"][$indice_array_p_p];
                $indice_array_producto++;
                $indice_array_p_p++;
                }
                else
                {
                    if($pp_eval!=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(9,$filas_excel)->getValue()) //si el no esta repetido
                    {
                    $producto_p["id_producto"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
                    $producto_p["id_proceso"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(9,$filas_excel)->getValue();
                    $producto_p["unidades_pulso"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(10,$filas_excel)->getValue();
                    $producto_p["var_pp1"][$indice_array_p_p]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(11,$filas_excel)->getValue();
                    $pp_eval=$producto_p["id_proceso"][$indice_array_p_p];
                     $indice_array_p_p++;
                    }
                $res=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(20,$filas_excel)->getValue();
                if($res!="") //si hay receta
                {
                $receta["id_producto"][$indice_array_receta]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
                $receta["id_material"][$indice_array_receta]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(20,$filas_excel)->getValue();
                $receta["cantidad"][$indice_array_receta]=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(21,$filas_excel)->getValue();
                $indice_array_receta++;
                }
                $producto_eva=$valor_celda;
                }
    $filas_excel++;
   }
}
//print_r($productos["id_producto"]);

//print_r($producto_p);

//print_r($receta["cantidad"]);

$objPHPExcel->setActiveSheetIndex(6);//Empleados
$leer_siguiente=1;
$filas_excel=3;
$indice_array=0;
$valor_celda="";
while($leer_siguiente==1)
{
   $valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   if($valor_celda=="")
   {
       $leer_siguiente=0;
   }
   else
   {
   $empleados["id_empleado"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   $empleados["nombre"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$filas_excel)->getValue();
   $empleados["cargo"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$filas_excel)->getValue();
   $empleados["clave"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(3,$filas_excel)->getValue();
   $empleados["nivel"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(4,$filas_excel)->getValue();
   $filas_excel++;
   $indice_array++;
   }
}
//print_r($empleados);




$objPHPExcel->setActiveSheetIndex(7);//Paradas
$leer_siguiente=1;
$filas_excel=3;
$indice_array=0;
$valor_celda="";
while($leer_siguiente==1)
{
   $valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   if($valor_celda=="")
   {
       $leer_siguiente=0;
   }
   else
   {
   $paradas["id_parada"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(0,$filas_excel)->getValue();
   $paradas["nombre"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(1,$filas_excel)->getValue();
   $paradas["tipo"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(2,$filas_excel)->getValue();
   $paradas["grupo"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(3,$filas_excel)->getValue();
   $paradas["unidad"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(4,$filas_excel)->getValue();
   $paradas["tiempo_prog"][$indice_array]=$valor_celda=$objPHPExcel->getActiveSheet()->getCellByColumnAndRow(6,$filas_excel)->getValue();
   $filas_excel++;
   $indice_array++;
   }
}
//print_r($paradas);

//inserter plantas
$registros= count($plantas["id_planta"]);
$i=0;
echo "Registrando Plantas..<br>";
for($i=0;$i<$registros;$i++)
{
    if($datos->comprobar_planta($plantas["id_planta"][$i]))
    {
    $datos->actualizar_planta($plantas["id_planta"][$i],$plantas["nombre"][$i],$plantas["descripcion"][$i],"on");
    }
    else
    {
       $datos->registro_planta($plantas["id_planta"][$i],$plantas["nombre"][$i],$plantas["descripcion"][$i],"on");
    }
}
echo "Registrando Plantas finalizado..<br>";

//---------------------------

$registros= count($procesos["id_proceso"]);
$i=0;
echo "Registrando Procesos..<br>";
for($i=0;$i<$registros;$i++)
{
    if($procesos["tipo_captura"][$i]=="Manual")
    {$captura=0;}
    else
    {$captura=1;}

    if($datos->comprobar_proceso($procesos["id_proceso"][$i]))
    {
        $datos->actualizar_proceso($procesos["id_proceso"][$i], $procesos["nombre"][$i], $procesos["descripcion"][$i], "on", $procesos["id_planta"][$i], $procesos["max_horas"][$i],$procesos["ip"][$i], $captura);
    }
    else
    {
        $datos->registro_proceso($procesos["id_proceso"][$i], $procesos["nombre"][$i], $procesos["descripcion"][$i], "on", $procesos["id_planta"][$i], $procesos["max_horas"][$i],$procesos["ip"][$i], $captura);
    }
}
echo "Registrando Procesos finalizado..<br>";



//---------------------------

$registros= count($materiales["id_material"]);
$i=0;
echo "Registrando Materiales..<br>";
for($i=0;$i<$registros;$i++)
{
    if($datos->comprobar_material($materiales["id_material"][$i]))
    {
        $datos->actualizar_material($materiales["id_material"][$i], $materiales["nombre"][$i], $materiales["descripcion"][$i], $materiales["unidad"][$i]);
    }
    else
    {
        $datos->registro_material($materiales["id_material"][$i], $materiales["nombre"][$i], $materiales["descripcion"][$i], $materiales["unidad"][$i]);
    }
}
echo "Registrando Materiales finalizado..<br>";



//---------------------------

$registros= count($productos["id_producto"]);
$i=0;
echo "Registrando Productos..<br>";
for($i=0;$i<$registros;$i++)
{
    if($datos->comprobar_producto($productos["id_producto"][$i]))
    {
        $datos->actualizar_producto($productos["id_producto"][$i],$productos["nombre"][$i],$productos["descripcion"][$i],0,0,0,0,"on");
    }
    else
    {
        $datos->registro_producto($productos["id_producto"][$i],$productos["nombre"][$i],$productos["descripcion"][$i],0,0,0,0,"on");
    }
}
echo "Registrando Productos finalizado..<br>";


//---------------------------

$registros= count($producto_p["id_producto"]);
$i=0;
echo "Registrando Producto-Proceso..<br>";
for($i=0;$i<$registros;$i++)
{
    if($datos->comprobar_producto_proceso($producto_p["id_producto"][$i],$producto_p["id_proceso"][$i]))
    {
        $datos->actualizar_producto_proceso($producto_p["id_proceso"][$i], $producto_p["id_producto"][$i],$producto_p["unidades_pulso"][$i], $producto_p["var_pp1"][$i], 0, 0);
    }
    else
    {
        $datos->registro_producto_proceso($producto_p["id_proceso"][$i], $producto_p["id_producto"][$i],$producto_p["unidades_pulso"][$i], $producto_p["var_pp1"][$i], 0, 0);
    }
}
echo "Registrando Producto-Proceso finalizado..<br>";


//---------------------------

$registros= count($receta["id_producto"]);
$i=0;
echo "Registrando Recetas..<br>";
for($i=0;$i<$registros;$i++)
{
    if($datos->comprobar_receta($receta["id_producto"][$i],$receta["id_material"][$i]))
    {
       
    }
    else
    {
        $datos->registro_receta($receta["id_producto"][$i],$receta["id_material"][$i],$receta["cantidad"][$i]);
    }
}
echo "Registrando Recetas finalizado..<br>";


//---------------------------

$registros= count($empleados["id_empleado"]);
$i=0;
echo "Registrando Empleados..<br>";
for($i=0;$i<$registros;$i++)
{
    if($datos->comprobar_personal($empleados["id_empleado"][$i]))
    {
        $datos->actualizar_personal($empleados["id_empleado"][$i], $empleados["nombre"][$i], $empleados["cargo"][$i], $empleados["clave"][$i], $empleados["nivel"][$i], "on", 0);
    }
    else
    {
        $datos->registro_personal($empleados["id_empleado"][$i], $empleados["nombre"][$i], $empleados["cargo"][$i], $empleados["clave"][$i], $empleados["nivel"][$i], "on", 0);
    }
}
echo "Registrando Empleados finalizado..<br>";


//---------------------------

$registros= count($paradas["id_parada"]);
$i=0;
echo "Registrando Paradas..<br>";
for($i=0;$i<$registros;$i++)
{
$tipo=1;
$grupo=1;
if($paradas["tipo"][$i]=="PROGRAMADA")
{
    $tipo=1;
}
else
{
    $tipo=2;
}

if($paradas["grupo"][$i]=="Averias")
{
    $grupo=1;
}
else
{
    if($paradas["grupo"][$i]=="Cuadres y ajustes")
    {
        $grupo=2;
    }
        else
    {
        $grupo=2;
    }
}
$tiempo=$paradas["tiempo_prog"][$i]*60;
    if($datos->comprobar_parada($paradas["id_parada"][$i]))
    {
       $datos->actualizar_parada($paradas["id_parada"][$i], $paradas["nombre"][$i], $tipo, 1, 0, "on", $grupo, $tiempo);
    }
    else
    {
       $datos->registro_parada($paradas["id_parada"][$i], $paradas["nombre"][$i], $tipo, 1, 0, "on", $grupo, $tiempo);
    }
}
echo "Registrando Paradas finalizado..<br><br><br><br>";

       $pagina="../administrar_datos.php";
       echo "la Informacion fue cargada a la base de datos con exito.";
       echo "<meta http-equiv=\"refresh\" content=\"2;URL=".$pagina."\">";
?>


